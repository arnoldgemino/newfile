package com.example.tvs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class citations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.citations);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ImageView img1 = findViewById(R.id.citations_home);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(citations.this,dashboard_admin.class);
                startActivity(intent);
            }
        });

        ImageView img2 = findViewById(R.id.citations_car);

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(citations.this,admin_addcar.class);
                startActivity(intent);
            }
        });

        ImageView img3 = findViewById(R.id.citations_caution);

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(citations.this,admin_addviolation.class);
                startActivity(intent);
            }
        });

        ImageView img4 = findViewById(R.id.citations_payments);

        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(citations.this,payments.class);
                startActivity(intent);
            }
        });

        ImageView img6= findViewById(R.id.citations_Driver);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(citations.this,admin_adddriver.class);
                startActivity(intent);
            }
        });

        ImageView img7= findViewById(R.id.logout);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(citations.this,logout.class);
                startActivity(intent);
            }
        });
    }
}