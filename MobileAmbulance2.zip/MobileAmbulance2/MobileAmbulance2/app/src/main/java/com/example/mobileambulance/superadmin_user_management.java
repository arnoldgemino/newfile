package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class superadmin_user_management extends AppCompatActivity {

    private ImageView Hospitals;
    private ImageView Dashboard;
    private ImageView Analytics;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_superadmin_user_management);

        Hospitals = findViewById(R.id.Hospitals);
        Hospitals.setOnClickListener(v -> {
            startActivity(new Intent(this, superadmin_hospital_management.class));
        });

        Dashboard = findViewById(R.id.Dashboard);
        Dashboard.setOnClickListener(v -> {
            startActivity(new Intent(this, super_admin_dashboard.class));
        });

        Analytics = findViewById(R.id.Analytics);
        Analytics.setOnClickListener(v -> {
            startActivity(new Intent(this, superadmin_analytics_reports.class));
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.superadmin_user_management), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

       TextView txt_add_new_admin =  findViewById(R.id.txt_add_new_admin);

        txt_add_new_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(superadmin_user_management.this,superadmin_new_admin.class);
                startActivity(intent);
            }
        });

        ImageView back =  findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(superadmin_user_management.this,superadmin_hospital_management.class);
                startActivity(intent);
            }
        });

    }
}