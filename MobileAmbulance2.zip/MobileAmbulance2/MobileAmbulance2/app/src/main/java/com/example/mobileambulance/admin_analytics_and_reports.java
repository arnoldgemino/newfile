package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_analytics_and_reports extends AppCompatActivity {

    private TextView Dashboard;
    private TextView Ambulances;
    private TextView Requests;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_analytics_and_reports);

        Dashboard = findViewById(R.id.Dashboard);
        Dashboard.setOnClickListener(v -> {
            startActivity(new Intent(this, admin_dashboard_overview.class));
        });

        Ambulances = findViewById(R.id.Ambulance);
        Ambulances.setOnClickListener(v -> {
            startActivity(new Intent(this, admin_ambulance_management.class));
        });

        Requests = findViewById(R.id.Requests);
        Requests.setOnClickListener(v -> {
            startActivity(new Intent(this, admin_all_request.class));
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.admin_analytics_and_reports), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}