package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class superadmin_hospital_management extends AppCompatActivity {

    private ImageView Dashboard;
    private ImageView Admins;
    private ImageView Analytics;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_superadmin_hospital_management);

        Dashboard = findViewById(R.id.Dashboard);
        Dashboard.setOnClickListener(v -> {
            Intent intent = new Intent(superadmin_hospital_management.this, super_admin_dashboard.class);
            startActivity(intent);
        });

        Analytics = findViewById(R.id.Analytics);
        Analytics.setOnClickListener(v -> {
            Intent intent = new Intent(superadmin_hospital_management.this, superadmin_analytics_reports.class);
            startActivity(intent);
        });

        Admins = findViewById(R.id.Admins);
        Admins.setOnClickListener(v -> {
            Intent intent = new Intent(superadmin_hospital_management.this, superadmin_user_management.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.superadmin_hospital_management), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txt_add_new_hospital =  findViewById(R.id.txt_add_new_hospital);

        txt_add_new_hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(superadmin_hospital_management.this,superadmin_add_new_hospital.class);
                startActivity(intent);
            }
        });

        ImageView txt_add_new_admin =  findViewById(R.id.back);

        txt_add_new_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(superadmin_hospital_management.this,super_admin_dashboard.class);
                startActivity(intent);
            }
        });

    }
}